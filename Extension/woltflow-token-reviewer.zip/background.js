// Background service worker for WoltFlow Token Reviewer
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    console.log("WoltFlow Token Reviewer extension installed");
  }
});

// Handle any background tasks if needed
chrome.action.onClicked.addListener((tab) => {
  // This will open the popup (default behavior)
  // No additional action needed for Manifest V3
});

// Optional: Add context menu for advanced users
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "WoltFlow-token-reviewer",
    title: "Review Wolt Tokens",
    contexts: ["page"],
    documentUrlPatterns: ["*://*.wolt.com/*"],
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "WoltFlow-token-reviewer") {
    // Open the popup programmatically
    chrome.action.openPopup();
  }
});
