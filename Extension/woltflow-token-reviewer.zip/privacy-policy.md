# Privacy Policy for WoltFlow Token Reviewer

**Last updated: January 2025**

## Overview

WoltFlow Token Reviewer is a Chrome extension that reviews access and refresh tokens from Wolt.com cookies.

## Data Collection and Usage

### What We Collect

- **Cookies**: The extension reads cookies from Wolt.com domains to extract authentication tokens
- **Configuration**: Token cookie names you specify are stored locally in Chrome's sync storage
- **No Personal Data**: We do not collect, store, or transmit any personal information

### How We Use Data

- **Local Processing Only**: All token extraction and processing happens locally on your device
- **No Remote Transmission**: Tokens and cookie data are never sent to external servers
- **Configuration Storage**: Cookie names are stored locally to remember your preferences

### Data Storage

- **Local Storage**: All data is stored locally using Chrome's storage APIs
- **No Cloud Storage**: No data is stored on external servers or cloud services
- **User Control**: You can clear all stored data by removing the extension

## Permissions

### Required Permissions

- **Cookies**: To read authentication tokens from Wolt.com cookies
- **Storage**: To save your token configuration preferences
- **Host Permission (\*.wolt.com)**: To access cookies specifically from Wolt domains

### Permission Usage

- Permissions are used only for their stated purpose
- No unnecessary data access or collection
- Minimal permission scope limited to Wolt.com domains only

## Security

### Token Handling

- **Local Only**: Tokens are displayed only in the extension popup
- **No Transmission**: Tokens are never sent over the network
- **User Responsibility**: Users must ensure they have authorization to access displayed tokens
- **Temporary Display**: Tokens are shown only while the popup is open

### Data Protection

- All processing happens locally on your device
- No analytics or tracking
- No external dependencies or remote resources

## User Rights and Control

### Your Controls

- **Disable Extension**: You can disable or remove the extension at any time
- **Clear Data**: Removing the extension clears all stored configuration
- **Permission Management**: You can revoke permissions through Chrome settings

### Your Responsibilities

- Ensure you have proper authorization to access tokens
- Protect any tokens you view or copy
- Use the extension only for legitimate development/debugging purposes

## Third Party Services

This extension does not integrate with any third-party services and does not share data with external parties.

## Changes to This Policy

We may update this privacy policy from time to time. Any changes will be reflected in the extension's metadata and documentation.

## Contact

For questions about this privacy policy or the extension, please contact: [YOUR_CONTACT_EMAIL]

## Compliance

This extension is designed to comply with:

- Chrome Web Store policies
- General data protection regulations
- Browser security best practices

---

**Note**: Handle tokens responsibly and ensure appropriate usage.
